# Decimal to Binary Converter

## Project Structure

```
decimal-to-binary
├── src
│   └── ProblemSession2.c        # Main program for decimal to binary conversion
├── docs
│   └── overview.md    # Overview of the conversion approach
└── README.md          # General information about the project
```

## Usage

Upon execution, the program prompts the user to enter a decimal integer. It then displays the corresponding binary representation.